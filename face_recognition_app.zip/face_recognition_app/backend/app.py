
from flask import Flask, request, jsonify
import face_recognition
import numpy as np

app = Flask(__name__)

# Load known face encodings and names
known_faces = np.load('known_faces.npy')
known_names = np.load('known_names.npy')

@app.route('/recognize', methods=['POST'])
def recognize():
    # Load image from the request
    image = face_recognition.load_image_file(request.files['image'])
    encodings = face_recognition.face_encodings(image)

    for encoding in encodings:
        matches = face_recognition.compare_faces(known_faces, encoding)
        if True in matches:
            index = matches.index(True)
            name = known_names[index]
            return jsonify({'name': name, 'status': 'authorized'})
    
    return jsonify({'name': 'unknown', 'status': 'unauthorized'})

if __name__ == '__main__':
    app.run(debug=True)
