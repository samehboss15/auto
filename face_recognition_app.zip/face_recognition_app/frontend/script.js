
function uploadImage() {
    var input = document.getElementById('imageInput');
    var file = input.files[0];
    var formData = new FormData();
    formData.append('image', file);

    fetch('/recognize', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if(data.status === 'authorized') {
            var confirmOpening = confirm(`Recognized ${data.name}. Do you want to open the door?`);
            if(confirmOpening) {
                alert('The door will open now.');
                // Here you can send a request to open the door
            } else {
                alert('Door opening canceled.');
            }
        } else {
            alert('Face not recognized. Unauthorized access.');
        }
    })
    .catch(error => console.error('Error:', error));}